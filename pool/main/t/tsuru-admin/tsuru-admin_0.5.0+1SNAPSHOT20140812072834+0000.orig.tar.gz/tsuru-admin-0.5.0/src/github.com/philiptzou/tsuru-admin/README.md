#tsuru-admin

[![Build Status](https://drone.io/github.com/tsuru/tsuru-admin/status.png?branch=master)](https://drone.io/github.com/tsuru/tsuru-admin/latest)
[![Build Status](https://travis-ci.org/tsuru/tsuru-admin.png?branch=master)](https://travis-ci.org/tsuru/tsuru-admin)

tsuru-admin is a command line for cloud administrators on
[tsuru](https://github.com/tsuru/tsuru).
