go build .
killall screen
sudo cp tsr /home/vagrant/go/bin/
/vagrant/tsr-screen.sh
