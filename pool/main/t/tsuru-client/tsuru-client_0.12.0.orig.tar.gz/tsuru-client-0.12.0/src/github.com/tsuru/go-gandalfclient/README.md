Go Gandalf Client is a client package for [Gandalf](https://github.com/globocom/gandalf)

[![build status](https://secure.travis-ci.org/globocom/go-gandalfclient.png)](http://travis-ci.org/globocom/go-gandalfclient)
