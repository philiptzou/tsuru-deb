:title: Managing tsuru
:description: guide for operations engineers managing tsuru.

.. _managing:

Managing
========

.. toctree::

    add-platform
    create-platform
    backup
    segregate-scheduler
