:title: Understanding tsuru
:description: Get started with tsuru, the Open source Platform as a Service (PaaS).

.. _understanding:

Understanding
=============

.. toctree::

    overview
    concepts
    architecture
