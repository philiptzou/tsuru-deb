// Copyright 2013 tsuru authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

/*
Package api implements the REST api for tsuru.

It provides the REST api for manage users, teams, apps and services.
*/
package api
