mongoapi changelog
==================

0.2.0
-----

* Remove binds from database when removing the instance.

0.1.1
-----

* Fix data race in bind handler

0.1.0
-----

* Initial release
* Support for all [Tsuru
  operations](http://docs.tsuru.io/en/latest/services/build.html), limiting one
  instance per app
