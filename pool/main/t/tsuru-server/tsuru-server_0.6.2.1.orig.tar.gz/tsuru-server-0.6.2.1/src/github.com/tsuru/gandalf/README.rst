.. image:: https://secure.travis-ci.org/tsuru/gandalf.png
   :target: http://travis-ci.org/tsuru/gandalf

+++++++
Gandalf
+++++++

Gandalf is a REST api written in go to manage git repositories, users and provide access to them over SSH.

YOU SHALL NOT PASS!
==================

First steps:
============

* `Installation guide <https://gandalf.readthedocs.org/en/latest/install.html>`_
* `Quickstart tutorial <https://gandalf.readthedocs.org/en/latest/quickstart.html>`_

Get involved:
=============

* `contribute <https://gandalf.readthedocs.org/en/latest/contribute.html>`_
* `community <https://gandalf.readthedocs.org/en/latest/community.html>`_

For more information see the `documentation <https://gandalf.readthedocs.org/en/latest/index.html>`_
