=======
Gandalf
=======

Gandalf is a REST api written in go to manage git repositories, users and provide access to them over SSH.

YOU SHALL NOT PASS!
==================

First steps:
============

* :doc:`Installation </install>`
* :doc:`Quickstart tutorial </quickstart>`

Get involved:
=============
* :doc:`Contribute </contribute>`
* :doc:`Community </community>`

Other topcis:
=============

* :doc:`API </api>`
* :doc:`Making a backup </making-backup>`
* :doc:`Install gandalf from source </install-from-source>`
