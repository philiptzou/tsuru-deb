This directory contains code pertaining to the Docker API:

 - Used by the docker client when comunicating with the docker deamon

 - Used by third party tools wishing to interface with the docker deamon
