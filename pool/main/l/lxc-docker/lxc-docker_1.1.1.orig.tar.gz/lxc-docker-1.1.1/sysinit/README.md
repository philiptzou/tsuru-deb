Sys Init code

This code is run INSIDE the container and is responsible for setting
up the environment before running the actual process
