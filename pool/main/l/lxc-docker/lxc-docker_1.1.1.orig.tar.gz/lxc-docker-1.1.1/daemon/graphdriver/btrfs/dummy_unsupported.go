// +build !linux !amd64

package btrfs
