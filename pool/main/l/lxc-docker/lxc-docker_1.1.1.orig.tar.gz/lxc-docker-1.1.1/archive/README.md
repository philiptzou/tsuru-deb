This code provides helper functions for dealing with archive files.

**TODO**: Move this to either `pkg` or (if not possible) to `utils`.
