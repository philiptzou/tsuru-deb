% DOCKER(1) Docker User Manuals
% Docker Community
% JUNE 2014
# NAME
docker-pause - Pause all processes within a container

# SYNOPSIS
**docker pause**
CONTAINER

# OPTIONS
There are no available options.

# HISTORY
June 2014, updated by Sven Dowideit <SvenDowideit@home.org.au>
