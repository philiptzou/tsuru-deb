page_title: The Docker Hub Registry Help
page_description: The Docker Registry help documentation home
page_keywords: Docker, docker, registry, accounts, plans, Dockerfile, Docker Hub, docs, documentation

# The Docker Hub Registry Help

## Introduction

For your questions about the [Docker Hub](https://hub.docker.com) registry you
can use [this documentation](docs.md).

If you can not find something you are looking for, please feel free to
[contact us](https://docker.com/resources/support/).
