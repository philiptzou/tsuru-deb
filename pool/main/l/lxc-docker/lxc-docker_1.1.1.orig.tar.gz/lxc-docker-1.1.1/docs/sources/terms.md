# Glossary

*Definitions of terms used in Docker documentation.*

## Contents:

 - [File System](filesystem/)
 - [Layers](layer/)
 - [Image](image/)
 - [Container](container/)
 - [Registry](registry/)
 - [Repository](repository/)

