`testutils` is a collection of utility functions to facilitate the writing
of tests. It is used in various places by the Docker test suite.
