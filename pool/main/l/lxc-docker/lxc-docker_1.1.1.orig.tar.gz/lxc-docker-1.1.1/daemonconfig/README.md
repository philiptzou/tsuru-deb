This directory contains code pertaining to the configuration of the docker deamon

These are the configuration settings that you pass to the docker daemon when you launch it with say: `docker -d -e lxc`
