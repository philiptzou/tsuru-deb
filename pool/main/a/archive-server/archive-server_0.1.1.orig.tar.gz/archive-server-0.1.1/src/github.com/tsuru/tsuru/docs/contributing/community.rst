.. Copyright 2014 tsuru authors. All rights reserved.
   Use of this source code is governed by a BSD-style
   license that can be found in the LICENSE file.

+++++++++
community
+++++++++

irc channel
===========

#tsuru channel on irc.freenode.net - chat with other tsuru users and developers

ticket system
=============

`ticket system <https://github.com/tsuru/tsuru/issues>`_ - report bugs and make feature requests
