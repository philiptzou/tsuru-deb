.. Copyright 2014 tsuru authors. All rights reserved.
   Use of this source code is governed by a BSD-style
   license that can be found in the LICENSE file.

++++++++++++
Contributing
++++++++++++

* Source hosted at `GitHub <http://github.com/tsuru/tsuru>`_
* Report issues on `GitHub Issues <http://github.com/tsuru/tsuru/issues>`_

Pull requests are very welcome! Make sure your patches are well tested and documented :)


Development environment
=======================

See this guide to :doc:`to setup a development environment using vagrant </contributing/vagrant>`.

And follow our :doc:`coding style guide </contributing/coding-style>`.

Running the tests
=================

You can use `make` to install all tsuru dependencies and run tests. It will also check if everything is ok with your `GOPATH` setup:

.. highlight:: bash

::

    $ make

Writing docs
============

tsuru documentation is written using `Sphinx <http://sphinx.pocoo.org/>`_,
which uses `RST <http://docutils.sourceforge.net/rst.html>`_.
Check these tools docs to learn how to write docs for tsuru.

Building docs
=============

In order to build the HTML docs, just run on terminal:

.. highlight:: bash

::

    $ make doc

Community
=========

irc channel
-----------

#tsuru channel on irc.freenode.net - chat with other tsuru users and developers.

.. toctree::
    :hidden:

    coding-style
    vagrant
