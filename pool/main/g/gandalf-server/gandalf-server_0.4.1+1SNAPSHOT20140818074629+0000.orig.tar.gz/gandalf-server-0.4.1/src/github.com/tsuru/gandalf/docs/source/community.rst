=========
Community
=========

irc channel
===========

#tsuru channel on irc.freenode.net - chat with other gandalf users and developers

ticket system
=============

`ticket system <https://github.com/tsuru/gandalf/issues>`_ - report bugs and make feature requests
