#crane

[![Build Status](https://drone.io/github.com/tsuru/crane/status.png?branch=master)](https://drone.io/github.com/tsuru/crane/latest)
[![Build Status](https://travis-ci.org/tsuru/crane.png?branch=master)](https://travis-ci.org/tsuru/crane)

crane is a command line for service providers/administrators on
[tsuru](https://github.com/tsuru/tsuru).
