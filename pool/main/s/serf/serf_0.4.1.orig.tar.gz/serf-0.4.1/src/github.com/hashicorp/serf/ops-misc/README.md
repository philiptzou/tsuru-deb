# ops-misc

This folder is used to share files that are not part of the Serf binary,
but are useful for operational purposes. For example, upstart scripts.
