/**package
* { "name": "npm-test-peer-deps-file"
* , "main": "index.js"
* , "version": "1.2.3"
* , "description":"No package.json in sight!"
* , "peerDependencies": { "underscore": "1.3.1" }
* , "dependencies": { "mkdirp": "0.3.5" }
* }
**/

module.exports = "I\'m just a lonely index, naked as the day I was born."
